create TYPE persoanaa AS OBJECT(
 cnp number,
 nume varchar2(30),
 prenume varchar2(30),
 telefon number,
 email varchar2(30), 
CONSTRUCTOR FUNCTION persoanaa( cnp NUMBER, nume VARCHAR2, prenume VARCHAR2, telefon NUMBER , email VARCHAR2) RETURN SELF AS RESULT
);
/

