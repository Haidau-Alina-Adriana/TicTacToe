create TYPE BODY persoanaa AS
    CONSTRUCTOR FUNCTION persoanaa (
        cnp   NUMBER,
        nume      VARCHAR2,
        regizor   VARCHAR2,
        telefon number,
        email VARCHAR2
    ) RETURN SELF AS RESULT AS
    BEGIN
        self.cnp:=cnp;
        self.nume := nume;
        self.prenume := prenume;
        self.telefon:= tefefon;
        self.email:=email;
        return;
    END;
END;
/

